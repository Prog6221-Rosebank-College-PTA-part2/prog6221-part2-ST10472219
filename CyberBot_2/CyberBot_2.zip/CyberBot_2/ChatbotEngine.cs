﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CyberBot_2
{
    public class ChatbotEngine
    {
        private Dictionary<string, List<string>> responses;

        private Random random = new Random();

        private string currentTopic = "";
        private string userName = "";

        public ChatbotEngine()
        {
            responses = new Dictionary<string, List<string>>();

            // PASSWORD
            responses["password"] = new List<string>()
            {
                "Use strong passwords with symbols and numbers.",
                "Never reuse passwords across accounts.",
                "Enable extra protection for your important accounts."
            };

            // PHISHING
            responses["phishing"] = new List<string>()
            {
                "Avoid clicking suspicious links.",
                "Check sender email addresses carefully.",
                "Phishing scams often pretend to be trusted companies."
            };

            // PRIVACY
            responses["privacy"] = new List<string>()
            {
                "Review your privacy settings regularly.",
                "Avoid sharing personal information online.",
                "Protect your accounts with strong passwords."
            };

            // SCAMS
            responses["scam"] = new List<string>()
            {
                "Never share OTPs with strangers.",
                "Verify information before sending money.",
                "Scammers often create fake urgency."
            };

            // MALWARE
            responses["malware"] = new List<string>()
            {
                "Install antivirus software to protect your computer.",
                "Avoid downloading files from unknown websites.",
                "Keep your software updated regularly."
            };

            // VIRUS
            responses["virus"] = new List<string>()
            {
                "Viruses can damage files and slow your computer.",
                "Always scan USB devices before opening files.",
                "Use trusted antivirus software."
            };

            // HACKERS
            responses["hacker"] = new List<string>()
            {
                "Hackers often target weak passwords.",
                "Avoid sharing sensitive information online.",
                "Update software regularly to reduce risks."
            };

            // CYBERBULLYING
            responses["cyberbullying"] = new List<string>()
            {
                "Block and report cyberbullies immediately.",
                "Save evidence of harmful online messages.",
                "Do not respond to cyberbullies online."
            };

            // SAFE BROWSING
            responses["safe browsing"] = new List<string>()
            {
                "Only visit trusted websites.",
                "Avoid downloading suspicious files.",
                "Check for HTTPS before entering sensitive information."
            };
        }

        // MAIN CHATBOT METHOD
        public string GetResponse(string input)
        {
            input = input.ToLower();

            // ERROR HANDLING
            if (string.IsNullOrWhiteSpace(input))
            {
                return "Please type a message.";
            }

            // GREETINGS
            if (input.Contains("hello") ||
                input.Contains("hi") ||
                input.Contains("hey"))
            {
                return "Hello! I am CyberSafe Bot. How can I help you stay safe online today?";
            }

            // GOODBYE
            if (input.Contains("bye") ||
                input.Contains("goodbye"))
            {
                return "Goodbye! Stay safe online and protect your information.";
            }

            // THANK YOU
            if (input.Contains("thank"))
            {
                return "You're welcome! Stay cyber safe.";
            }

            // MEMORY FEATURE
            if (input.StartsWith("my name is"))
            {
                userName = input.Replace("my name is", "").Trim();

                return "Nice to meet you, " + userName + "!";
            }

            // SENTIMENT DETECTION
            if (input.Contains("worried") ||
                input.Contains("frustrated") ||
                input.Contains("confused") ||
                input.Contains("scared") ||
                input.Contains("nervous"))
            {
                return "I understand your concern. Stay calm and avoid suspicious links or messages.";
            }

            // CONVERSATION FLOW
            if (input.Contains("more") ||
                input.Contains("explain"))
            {
                if (currentTopic == "phishing")
                {
                    return "Phishing attacks often pretend to be trusted companies or banks to steal information.";
                }

                if (currentTopic == "password")
                {
                    return "Strong passwords should contain uppercase letters, symbols, and numbers.";
                }

                if (currentTopic == "malware")
                {
                    return "Malware can steal information, damage files, and slow down computers.";
                }
            }

            // KEYWORD RECOGNITION
            foreach (var keyword in responses.Keys)
            {
                if (input.Contains(keyword))
                {
                    currentTopic = keyword;

                    int index = random.Next(responses[keyword].Count);

                    if (!string.IsNullOrEmpty(userName))
                    {
                        return userName + ", " + responses[keyword][index];
                    }

                    return responses[keyword][index];
                }
            }

            // DEFAULT RESPONSE
            return "I'm not sure I understand. Can you rephrase your question?";
        }
    }
}