﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;





namespace CyberBot_2
{
    public partial class MainWindow : Window
    {
        ChatbotEngine bot = new ChatbotEngine();

        public MainWindow()
        {
            InitializeComponent();

            rtbChat.Document.Blocks.Add(
                new Paragraph(
                    new Run("Welcome to CyberSafe Bot!\nAsk me about Phishing, scams, Passwords,Malaware, Virus, Hackers and Privacy.\n")));
        }

        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            string input = txtInput.Text;

            rtbChat.Document.Blocks.Add(
                new Paragraph(
                   new Run(DateTime.Now.ToShortTimeString()
+ " You: " + input)));

            string response = bot.GetResponse(input);

            rtbChat.Document.Blocks.Add(
                new Paragraph(
                   new Run(DateTime.Now.ToShortTimeString()
+ " Bot: " + response)));

            txtInput.Clear();
        }

        private void txtInput_KeyDown(object sender,
     System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                btnSend_Click(sender, e);
            }
        }
    }
}